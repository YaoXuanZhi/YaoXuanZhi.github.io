# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'input_color.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################
from PySide6.QtCore import Signal, Slot
from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
                            QMetaObject, QObject, QPoint, QRect,
                            QSize, QTime, QUrl, Qt, Signal)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QLayout, QLineEdit, QPushButton, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

class Ui_InputColor(QWidget):
    textEntered = Signal(str)  # 定义一个带有字符串参数的信号

    def __init__(self):
        super().__init__()
        self.drag_position = None


    def setupUi(self, Form):

        Form.setObjectName("Form")  # 直接设置对象名称
        Form.resize(200, 70)

        # 设置背景颜色和透明度
        Form.setWindowFlags(Qt.FramelessWindowHint)  # 设置无边框窗口
        Form.setAttribute(Qt.WA_TranslucentBackground)  # 设置窗口透明

        self.bg_gray = QFrame(Form)
        self.bg_gray.setObjectName(u"bg_gray")
        self.bg_gray.setGeometry(QRect(0, 0, 200, 65))
        self.bg_gray.setStyleSheet(u".QFrame{\n"
"	background-color: rgb(234,236,243);\n"
"	border-radius:5px;\n"
"}")
        self.bg_gray.setFrameShape(QFrame.StyledPanel)
        self.bg_gray.setFrameShadow(QFrame.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.bg_gray)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(10, 11, 4, 11)
        self.verticalLayout_2 = QVBoxLayout()
        # 设置右侧边距为5px
        self.verticalLayout_2.setContentsMargins(0, 0, 7, 0)

        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.window_top = QHBoxLayout()
        self.window_top.setSpacing(10)
        self.window_top.setObjectName(u"window_top")
        self.window_top.setSizeConstraint(QLayout.SetFixedSize)
        self.window_top.setContentsMargins(0, 0, 0, 0)
        self.text_title = QLabel(self.bg_gray)
        self.text_title.setObjectName(u"text_title")
        self.text_title.setStyleSheet(u"    font-size: 9pt;\n"
"    font-family: \"\u5fae\u8f6f\u96c5\u9ed1\";\n"
"    color: #333;\n"
"font-weight: bold;")

        self.window_top.addWidget(self.text_title)

        self.h_spacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.window_top.addItem(self.h_spacer)

        self.btn_min = QPushButton(self.bg_gray)
        self.btn_min.setObjectName(u"btn_min")
        sizePolicy = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.btn_min.sizePolicy().hasHeightForWidth())
        self.btn_min.setSizePolicy(sizePolicy)
        self.btn_min.setMaximumSize(QSize(10, 10))
        self.btn_min.setStyleSheet(u"QPushButton {\n"
"    background-color: #07BB2C;\n"
"    border: 2px solid #07BB2C;\n"
"    color: #3498db;\n"
"    padding: 1px;\n"
"    border-radius: 5px;\n"
"}\n"
" \n"
"QPushButton:hover {\n"
"    background-color: #09ED3A;\n"
"    color: #ffffff;\n"
"}")

        self.window_top.addWidget(self.btn_min)

        self.btn_max = QPushButton(self.bg_gray)
        self.btn_max.setObjectName(u"btn_max")
        self.btn_max.setMaximumSize(QSize(10, 10))
        self.btn_max.setStyleSheet(u"QPushButton {\n"
"    background-color: #FFB206;\n"
"    border: 2px solid #FFB206;\n"
"    color: #3498db;\n"
"    padding: 1px;\n"
"    border-radius: 5px;\n"
"}\n"
" \n"
"QPushButton:hover {\n"
"    background-color: #FFC033;\n"
"    color: #ffffff;\n"
"}")

        self.window_top.addWidget(self.btn_max)

        self.btn_stop = QPushButton(self.bg_gray)
        self.btn_stop.setObjectName(u"btn_stop")

        self.btn_stop.clicked.connect(self.close)  # 关联关闭窗口事件

        self.btn_stop.setMaximumSize(QSize(10, 10))
        self.btn_stop.setStyleSheet(u"\n"
"\n"
"QPushButton {\n"
"    background-color: #EE514A;\n"
"    border: 2px solid #EE514A;\n"
"    color: #3498db;\n"
"    padding: 1px;\n"
"    border-radius: 5;\n"
"}\n"
" \n"
"QPushButton:hover {\n"
"    background-color: #F1756F;\n"
"    color: #ffffff;\n"
"}")

        self.window_top.addWidget(self.btn_stop)


        self.verticalLayout_2.addLayout(self.window_top)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.lineEdit = QLineEdit(self.bg_gray)
        self.lineEdit.setObjectName(u"lineEdit")

        self.horizontalLayout.addWidget(self.lineEdit)

        self.b_submit = QPushButton(self.bg_gray)

        self.b_submit.clicked.connect(self.emitSignal)  # 点击按钮时连接到发射信号的方法

        self.b_submit.setObjectName(u"b_submit")
        self.b_submit.setMinimumSize(QSize(0, 0))
        self.b_submit.setStyleSheet(u"            QPushButton {\n"
"                border-style: solid;\n"
"                border-width: 2px;\n"
"                border-radius: 15px;\n"
"                border-color: rgb(88, 180, 107);\n"
"                font-size: 7pt;\n"
"                font-weight: bold;\n"
"                padding: 2px;\n"
"                background-color: rgb(88, 180, 107);\n"
"                color: rgb(255, 255, 255);\n"
"            }\n"
"            QPushButton:hover {\n"
"                border-color: rgb(100, 100, 100);\n"
"                background-color: rgb(183, 255, 189);\n"
"				color: rgb(88, 180, 107);\n"
"            }\n"
"            QPushButton:pressed {\n"
"                border-color: rgb(42, 42, 42);\n"
"                background-color: rgb(160, 255, 163);\n"
"				color: rgb(88, 180, 107);\n"
"            }")

        self.horizontalLayout.addWidget(self.b_submit)


        self.verticalLayout_2.addLayout(self.horizontalLayout)


        self.verticalLayout_3.addLayout(self.verticalLayout_2)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    @Slot()
    def emitSignal(self):
        text = self.lineEdit.text()
        self.textEntered.emit(text)  # 发射信号，并传递lineEdit中的文本

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.text_title.setText(QCoreApplication.translate("Form", u"\u8bf7\u8f93\u5165\u8272\u53f7", None))
        self.btn_min.setText("")
        self.btn_max.setText("")
        self.btn_stop.setText("")
        self.lineEdit.setPlaceholderText(QCoreApplication.translate("Form", u"255,255,255", None))
        self.b_submit.setText(QCoreApplication.translate("Form", u"\u786e\u8ba4", None))
    # retranslateUi
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_position = event.globalPos() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and self.drag_position:
            self.move(event.globalPos() - self.drag_position)
            event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_position = None
            event.accept()


if __name__ == "__main__":
    app = QApplication([])

    Form = QWidget()
    ui = Ui_InputColor()
    ui.setupUi(Form)
    Form.setWindowFlag(Qt.FramelessWindowHint)  # 设置窗口标志：隐藏窗口边框
    Form.show()

    app.exec()