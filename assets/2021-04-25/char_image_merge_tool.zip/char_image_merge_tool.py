import os, sys, glob, random, math
from PIL import Image, ImageDraw

char_count_as_single_line = 20  # 单行文字图片的文字数量
extra_bound_as_single_line = 10  # 单字图片的边界拓展大小

char_count_as_multi_line = 1000 # 多行文字图片的文字数量
extra_bound_as_multi_line = 10  # 单字图片的边界拓展大小

# 获得随机颜色
def get_random_color():
    return (random.randint(32, 127), random.randint(32, 127), random.randint(32, 127))

# 切换工作目录
def switch_work_dir(path):
    if not os.path.isdir(path):
        os.mkdir(path)
    os.chdir(path)
    print("当前工作目录："+os.getcwd())

# 合并成单行文字图片
def combine_image_with_lite(paths, merge_times, is_debug = False):
    count = len(paths)
    src_image = Image.open(paths[0])
    image_width, image_height = src_image.size 
    x = image_width + extra_bound_as_single_line
    y = image_height + extra_bound_as_single_line

    # 计算合并之后的大小
    full_x = x * count
    full_y = y
    full_size = (full_x, full_y)
    full_image = Image.new('RGBA', full_size, (255,255,255))
    full_image.format = "PNG"
    # print("full rect : {%d,%d,%d,%d}" % (0, 0, full_x, full_y))

    # 将图片块平铺到这个大图片上
    start_x = 0
    start_y = 0
    end_x = x
    end_y = y
    index = 1
    
    draw = ImageDraw.Draw(full_image)
    for path in paths:
        if is_debug == True:
            # 绘制每个填充区域的边界
            print("{%d,%d,%d,%d}" % (start_x, start_y, end_x, end_y))
            draw.rectangle((start_x+1, start_y+1, end_x-1, end_y-1), outline = get_random_color())

            # 居中绘制填充的图片索引
            index_str = "%d"%(index)
            font_size_x, font_size_y = draw.textsize(index_str)
            draw.text((start_x + (x-font_size_x)/2, start_y + (y-font_size_y)/2), index_str, fill='black')
        else:
            # 由于单字图片边界过小，如果直接平铺的话，就会显得太挤，OCR识别效果很差
            # 为此拓展单字图片的填充区域，并将图片在此中间叠加上去
            src_image = Image.open(path)
            start_x0 = start_x + (x-image_width)//2
            start_y0 = start_y + (y-image_height)//2
            end_x0 = start_x0 + image_width
            end_y0 = start_y0 + image_height
            full_image.paste(src_image, (start_x0, start_y0, end_x0, end_y0), src_image)

        index = index + 1
        if end_x >= full_x:
            # 从左往右填充，遇到边界之后切换到下一行
            start_x = 0
            end_x = start_x + x

            start_y = start_y + y
            end_y = start_y + y
        else:
            # 继续从左往右平铺
            start_x = start_x + x
            end_x = end_x + x

    current_dir = os.getcwd()
    output_path = '%s/../single_line_%d.png' % (current_dir, merge_times)
    full_image.save(output_path)

# 将单字图片合并成单行文字图片
def merge_image_as_single_line(work_path):
    switch_work_dir(work_path)
    image_paths = glob.glob("*.png")
    
    temp_paths = []
    merge_times = 1
    for path in image_paths:
        if len(temp_paths) >= char_count_as_single_line:
            combine_image_with_lite(temp_paths, merge_times)
            # combine_image_with_lite(temp_paths, merge_times, is_debug=True)
            merge_times = merge_times + 1
            temp_paths = []
        temp_paths.append(path)
    combine_image_with_lite(temp_paths, merge_times)
    # combine_image_with_lite(temp_paths, merge_times, is_debug=True)

# 合并成多行文字图片
def combine_image_with_multi(paths, merge_times, is_debug = False):
    count = len(paths)
    src_image = Image.open(paths[0])
    image_width, image_height = src_image.size 
    x = image_width + extra_bound_as_multi_line
    y = image_height + extra_bound_as_multi_line

    # 计算合并之后的单字图片平铺时的行列数
    sqrt2 = math.sqrt(count)
    row_num = round(sqrt2)
    column_num = row_num
    if sqrt2 > column_num:
        column_num = column_num + 1 
    print("总数：%d 开根号：%f 行：%d 列：%d" % (count, sqrt2, row_num, column_num))

    # 计算合并之后的图片尺寸
    full_x = x * column_num
    full_y = y * row_num
    full_size = (full_x, full_y)
    full_image = Image.new('RGBA', full_size, (255,255,255))
    print("full rect : {%d,%d,%d,%d}" % (0, 0, full_x, full_y))

    # 将图片块平铺到这个大图片上
    start_x = 0
    start_y = 0
    end_x = x
    end_y = y
    index = 1
    
    draw = ImageDraw.Draw(full_image)
    for path in paths:
        if is_debug == True:
            # 绘制每个填充区域的边界
            print("{%d,%d,%d,%d}" % (start_x, start_y, end_x, end_y))
            draw.rectangle((start_x+1, start_y+1, end_x-1, end_y-1), outline = get_random_color())

            # 居中绘制填充的图片索引
            index_str = "%d"%(index)
            font_size_x, font_size_y = draw.textsize(index_str)
            draw.text((start_x + (x-font_size_x)/2, start_y + (y-font_size_y)/2), index_str, fill='black')
        else:
            src_image = Image.open(path)
            start_x0 = start_x + (x-image_width)//2
            start_y0 = start_y + (y-image_height)//2
            end_x0 = start_x0 + image_width
            end_y0 = start_y0 + image_height
            full_image.paste(src_image, (start_x0, start_y0, end_x0, end_y0), src_image)

        index = index + 1
        if end_x >= full_x:
            # 从左往右填充，遇到边界之后切换到下一行
            start_x = 0
            end_x = start_x + x

            start_y = start_y + y
            end_y = start_y + y
        else:
            # 继续从左往右平铺
            start_x = start_x + x
            end_x = end_x + x

    current_dir = os.getcwd()
    output_path = '%s/../multi_line_%d.png' % (current_dir, merge_times)
    full_image.save(output_path)

# 将单字图片合并成多行文字图片
def merge_image_as_multi_line(work_path):
    switch_work_dir(work_path)
    image_paths = glob.glob("*.png")
    
    temp_paths = []
    merge_times = 1
    for path in image_paths:
        if len(temp_paths) >= char_count_as_multi_line:
            combine_image_with_multi(temp_paths, merge_times)
            # combine_image_with_multi(temp_paths, merge_times, is_debug=True)
            merge_times =  merge_times + 1
            temp_paths = []
        temp_paths.append(path)
    combine_image_with_multi(temp_paths, merge_times)
    # combine_image_with_multi(temp_paths, merge_times, is_debug=True)

if __name__ == '__main__':
    args = sys.argv

    # 获取配置文件路径
    work_path = "image"
    if len(args) > 1:
        work_path = args[1]
    merge_image_as_single_line(work_path)
    # merge_image_as_multi_line(work_path)