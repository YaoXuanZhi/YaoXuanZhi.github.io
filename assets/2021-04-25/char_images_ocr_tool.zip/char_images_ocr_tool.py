# !/user/bin/env python
# -*- coding:utf-8 -*- 
import os, sys, glob, random, math, codecs, re
from PIL import Image, ImageDraw
import json_helper, cnocr_helper
import argparse

char_count_as_single_line = 20  # 单行文字图片的文字数量
extra_bound_as_single_line = 10  # 单字图片的边界拓展大小

char_count_as_multi_line = 1000 # 多行文字图片的文字数量
extra_bound_as_multi_line = 10  # 单字图片的边界拓展大小
output_dir = "./"
is_debug = False
is_save_image = False

# 获得随机颜色
def get_random_color():
    return (random.randint(32, 127), random.randint(32, 127), random.randint(32, 127))

# 合并成单行文字图片
def combine_image_with_lite(paths, merge_times, handle_fun, is_debug = False):
    global extra_bound_as_single_line    
    global output_dir
    global is_save_image

    count = len(paths)
    src_image = Image.open(paths[0])
    image_width, image_height = src_image.size 
    x = image_width + extra_bound_as_single_line
    y = image_height + extra_bound_as_single_line

    # 计算合并之后的大小
    full_x = x * count
    full_y = y
    full_size = (full_x, full_y)
    full_image = Image.new('RGBA', full_size, (255,255,255))
    full_image.format = "PNG"
    # print("full rect : {%d,%d,%d,%d}" % (0, 0, full_x, full_y))

    # 将图片块平铺到这个大图片上
    start_x = 0
    start_y = 0
    end_x = x
    end_y = y
    index = 1
    
    draw = ImageDraw.Draw(full_image)
    for path in paths:
        if is_debug == True:
            # 绘制每个填充区域的边界
            print("{%d,%d,%d,%d}" % (start_x, start_y, end_x, end_y))
            draw.rectangle((start_x+1, start_y+1, end_x-1, end_y-1), outline = get_random_color())

            # 居中绘制填充的图片索引
            index_str = "%d"%(index)
            font_size_x, font_size_y = draw.textsize(index_str)
            draw.text((start_x + (x-font_size_x)/2, start_y + (y-font_size_y)/2), index_str, fill='black')
        else:
            # 由于单字图片边界过小，如果直接平铺的话，就会显得太挤，OCR识别效果很差
            # 为此拓展单字图片的填充区域，并将图片在此中间叠加上去
            src_image = Image.open(path)
            start_x0 = start_x + (x-image_width)//2
            start_y0 = start_y + (y-image_height)//2
            end_x0 = start_x0 + image_width
            end_y0 = start_y0 + image_height
            full_image.paste(src_image, (start_x0, start_y0, end_x0, end_y0), src_image)

        index = index + 1
        if end_x >= full_x:
            # 从左往右填充，遇到边界之后切换到下一行
            start_x = 0
            end_x = start_x + x

            start_y = start_y + y
            end_y = start_y + y
        else:
            # 继续从左往右平铺
            start_x = start_x + x
            end_x = end_x + x

    debug_prefix = ""
    if is_debug == True:
        debug_prefix = "debug_"

    output_path = '%s/%ssingle_line_%d.png' % (output_dir, debug_prefix, merge_times)
    if is_save_image == True or is_debug == True:
        full_image.save(output_path)
    if is_debug == False:
        handle_fun(full_image, paths, output_path)


# 将单字图片合并成单行文字图片
def merge_image_as_single_line(work_path):
    global output_dir
    global char_count_as_single_line
    global is_debug

    image_paths = glob.glob(os.path.join(work_path, "*.png"))

    # 加载ocr识别结果
    config_obj = json_helper.load_config(output_dir)
    ocr_result_obj = config_obj["ocr_result"]
    error_obj = json_helper.load_error_config(output_dir)

    # 合并之后，进行ocr识别
    def handle_fun(image, paths, output_path):
        ocr_text = cnocr_helper.ocr_image_from_pil(image)
        if len(ocr_text) == len(paths):
            for i in range(0, len(paths)):
                image_name = os.path.basename(paths[i])
                if image_name in ocr_result_obj:
                    print("skip %s %s" % (image_name, ocr_result_obj[image_name]))
                else:
                    if cnocr_helper.is_chs_char(ocr_text[i]):
                        ocr_result_obj[image_name] = ocr_text[i]
                    else:
                        error_obj[image_name] = ocr_text[i]
                        print("ocr error: %s" % (image_name))
        else:
            print("skip full line %s " % (output_path))
    
    temp_paths = []
    merge_times = 1
    for path in image_paths:
        if len(temp_paths) >= char_count_as_single_line:
            combine_image_with_lite(temp_paths, merge_times, handle_fun, is_debug)
            merge_times = merge_times + 1
            temp_paths = []
        temp_paths.append(path)
    combine_image_with_lite(temp_paths, merge_times, handle_fun, is_debug)
    if is_debug == False:
        json_helper.save_config(config_obj, output_dir)
        json_helper.save_error_config(error_obj, output_dir)

# 合并成多行文字图片
def combine_image_with_multi(paths, merge_times, handle_fun, is_debug = False):
    global extra_bound_as_multi_line
    global output_dir
    global is_save_image

    count = len(paths)
    src_image = Image.open(paths[0])
    image_width, image_height = src_image.size 
    x = image_width + extra_bound_as_multi_line
    y = image_height + extra_bound_as_multi_line

    # 计算合并之后的单字图片平铺时的行列数
    sqrt2 = math.sqrt(count)
    row_num = round(sqrt2)
    column_num = row_num
    if sqrt2 > column_num:
        column_num = column_num + 1 
    
    if is_debug == True:
        print("总数：%d 开根号：%f 行：%d 列：%d" % (count, sqrt2, row_num, column_num))

    # 计算合并之后的图片尺寸
    full_x = x * column_num
    full_y = y * row_num
    full_size = (full_x, full_y)
    full_image = Image.new('RGBA', full_size, (255,255,255))

    if is_debug == True:
        print("full rect : {%d,%d,%d,%d}" % (0, 0, full_x, full_y))

    # 将图片块平铺到这个大图片上
    start_x = 0
    start_y = 0
    end_x = x
    end_y = y
    index = 1
    
    draw = ImageDraw.Draw(full_image)
    for path in paths:
        if is_debug == True:
            # 绘制每个填充区域的边界
            print("{%d,%d,%d,%d}" % (start_x, start_y, end_x, end_y))
            draw.rectangle((start_x+1, start_y+1, end_x-1, end_y-1), outline = get_random_color())

            # 居中绘制填充的图片索引
            index_str = "%d"%(index)
            font_size_x, font_size_y = draw.textsize(index_str)
            draw.text((start_x + (x-font_size_x)/2, start_y + (y-font_size_y)/2), index_str, fill='black')
        else:
            src_image = Image.open(path)
            start_x0 = start_x + (x-image_width)//2
            start_y0 = start_y + (y-image_height)//2
            end_x0 = start_x0 + image_width
            end_y0 = start_y0 + image_height
            full_image.paste(src_image, (start_x0, start_y0, end_x0, end_y0), src_image)

        index = index + 1
        if end_x >= full_x:
            # 从左往右填充，遇到边界之后切换到下一行
            start_x = 0
            end_x = start_x + x

            start_y = start_y + y
            end_y = start_y + y
        else:
            # 继续从左往右平铺
            start_x = start_x + x
            end_x = end_x + x

    debug_prefix = ""
    if is_debug == True:
        debug_prefix = "debug_"
    output_path = '%s/%smulti_line_%d.png' % (output_dir, debug_prefix, merge_times)
    if is_save_image == True or is_debug == True:
        full_image.save(output_path)
    if is_debug == False:
        handle_fun(full_image, paths, output_path)

# 将单字图片合并成多行文字图片
def merge_image_as_multi_line(work_path):
    global output_dir
    global char_count_as_multi_line
    global is_debug

    image_paths = glob.glob(os.path.join(work_path, "*.png"))

    # 加载ocr识别结果
    config_obj = json_helper.load_config(output_dir)
    ocr_result_obj = config_obj["ocr_result"]
    error_obj = json_helper.load_error_config(output_dir)

    # 合并之后，进行ocr识别
    def handle_fun(image, paths, output_path):
        ocr_text = cnocr_helper.ocr_image_from_pil(image)
        ocr_text = ocr_text.replace("\n", "")
        ocr_text = ocr_text.replace("\r", "")
        if len(ocr_text) == len(paths):
            for i in range(0, len(paths)):
                image_name = os.path.basename(paths[i])
                if image_name in ocr_result_obj:
                    print("skip %s %s" % (image_name, ocr_result_obj[image_name]))
                else:
                    if cnocr_helper.is_chs_char(ocr_text[i]):
                        ocr_result_obj[image_name] = ocr_text[i]
                    else:
                        error_obj[image_name] = ocr_text[i]
                        print("ocr error: %s" % (image_name))
        else:
            print("skip full line %s " % (output_path))
    
    temp_paths = []
    merge_times = 1
    for path in image_paths:
        if len(temp_paths) >= char_count_as_multi_line:
            combine_image_with_multi(temp_paths, merge_times, handle_fun, is_debug)
            merge_times =  merge_times + 1
            temp_paths = []
        temp_paths.append(path)
    combine_image_with_multi(temp_paths, merge_times, handle_fun, is_debug)
    if is_debug == False:
        json_helper.save_config(config_obj, output_dir)
        json_helper.save_error_config(error_obj, output_dir)

# 根据校正文件来生成映射
def correct_ocr_result(work_path, correct_path):
    global output_dir

    image_paths = glob.glob(os.path.join(work_path, "*.png"))

    # 加载ocr识别结果
    config_obj = json_helper.load_config(output_dir)
    ocr_result_obj = config_obj["ocr_result"]
    error_obj = json_helper.load_error_config(output_dir)

    def handle_fun(paths, ocr_text):
        ocr_text = ocr_text.replace("\n", "")
        ocr_text = ocr_text.replace("\r", "")
        if len(ocr_text) == len(paths):
            for i in range(0, len(paths)):
                image_name = os.path.basename(paths[i])
                if image_name in ocr_result_obj:
                    print("skip %s %s" % (image_name, ocr_result_obj[image_name]))
                else:
                    if cnocr_helper.is_chs_char(ocr_text[i]):
                        ocr_result_obj[image_name] = ocr_text[i]
                    else:
                        error_obj[image_name] = ocr_text[i]
                        print("ocr error: %s" % (image_name))
        else:
            print("skip correct ocr result")

    # 加载校正文件内容
    if os.path.exists(correct_path):
        with codecs.open(correct_path, mode="r", encoding="utf-8", errors='ignore') as f:
            ocr_text = f.read()
            handle_fun(image_paths, ocr_text)
    else:
        print("not found %s/%s" % (os.getcwd(), correct_path))

    if is_debug == False:
        json_helper.save_config(config_obj, output_dir)
        json_helper.save_error_config(error_obj, output_dir)
            
# 替换html里面的字符图片标签
def replace_char_image_tag_in_html(work_path, json_path):
    global output_dir

    # 加载ocr识别结果
    config_obj = json_helper.load_config_from_path(json_path)
    ocr_result_obj = config_obj["ocr_result"]

    # 替换单字图片里的OCR文本
    def convert_fun(src_str):
        def replace_link(matched):
            src_str = matched.group(0)
            match_obj = re.search(r"(\d+.png)", src_str, re.M | re.I)
            image_link = match_obj.group()
            return ocr_result_obj[image_link]
        src_str = re.sub(r"(<img src=\"../../toimg/data/.*?.png\" />)", replace_link, src_str)
        return src_str

    # 遍历html文件执行替换处理
    def recursion_html_files(work_path, convert_fun):
        html_paths = glob.glob(os.path.join(work_path, "*.html"))
        for path in html_paths:
            with codecs.open(path, mode="r", encoding="utf-8", errors='ignore') as f:
                html_text = f.read()
                f.close()

                html_text = convert_fun(html_text)
                html_file_name = os.path.basename(path)
                output_path = os.path.join(output_dir, html_file_name)
                with codecs.open(output_path, mode="w", encoding="utf-8") as fw:
                    fw.write(html_text)
                    fw.close()

    recursion_html_files(work_path, convert_fun)
    pass

def main():
    # 命令行参数处理
    parser = argparse.ArgumentParser(description='在字符图片目录里进行OCR识别，并将结果导出到json文件上')

    parser.add_argument("-i", "--input",
        default="./",
        help='''输入路径
        [-s_ocr/m_ocr/t_ocr：字符图片所在目录]
        [-c_link：html文件所在目录]
        '''
    )
    parser.add_argument("-o", "--output",
        default="./",
        help='''输出路径
        [-s_ocr/m_ocr/t_ocr：ocr结果输出路径]
        [-c_link：转换后的html文件所在目录]
        '''
    )
    parser.add_argument("-s_ocr", "--single_ocr",
                            action="store_true",
                            help="先合并成单行文字图片再进行OCR识别，更新映射文件")
    parser.add_argument("-m_ocr", "--multi_ocr",
                            action="store_true",
                            help="先合并成多行文字图片再进行OCR识别，更新映射文件")
    parser.add_argument("-t_ocr", "--txt_ocr",
                            action="store_true",
                            help="使用校正文件来更新映射文件")
    parser.add_argument("-c_link", "--clear_char_image_tag",
                            action="store_true",
                            help="根据映射文件来将html里的字符图片标签替换成字符")
    parser.add_argument("-e", "--extra",
        metavar="N",
        nargs="+",
        type=int,
        default=[20, 10],
        help="输入[合并字符图片数量 字符图片边界拓展像素]"
    )
    parser.add_argument("-f", "--file",
        default="",
        help='''输入文件路径
        [-t_ocr：校正文本路径]
        [-c_link：映射文件路径]
        '''
    )
    parser.add_argument("-d", "--debug",
                            action="store_true",
                            help="调试模式执行")
    parser.add_argument("-save", "--is_save_image",
                            action="store_true",
                            help="保存合并后的图片")

    args = parser.parse_args()

    global output_dir
    global is_debug
    global is_save_image

    work_path = args.input
    output_dir = args.output
    is_debug = args.debug
    is_save_image = args.is_save_image

    if (args.single_ocr == True):
        # 先合并成单行文字图片再进行OCR识别，更新映射文件
        global char_count_as_single_line
        global extra_bound_as_single_line
        char_count_as_single_line = args.extra[0]
        extra_bound_as_single_line = args.extra[1]
        merge_image_as_single_line(work_path)
    elif (args.multi_ocr == True):
        # 先合并成多行文字图片再进行OCR识别，更新映射文件
        global char_count_as_multi_line
        global extra_bound_as_multi_line
        char_count_as_multi_line = args.extra[0]
        extra_bound_as_multi_line = args.extra[1]
        merge_image_as_multi_line(work_path)
    elif (args.txt_ocr == True):
        # 使用校正文件来更新映射文件
        correct_ocr_result(work_path, args.file)
    elif (args.clear_char_image_tag == True):
        # 根据映射文件来将html里的字符图片标签替换成字符
        replace_char_image_tag_in_html(work_path, args.file)

if __name__ == '__main__':
    main()