# !/user/bin/env python
# -*- coding:utf-8 -*- 
import numpy as np
from cnocr import CnOcr 

cn_ocr = CnOcr()

# 读取PIL image进行OCR识别
def ocr_image_from_pil(image):
    nd_array = np.asarray(image.convert('RGB'))
    return ocr_image_from_ndarray(nd_array)

# 读取ndarray进行OCR识别
def ocr_image_from_ndarray(nd_array):
    res_lines = cn_ocr.ocr(nd_array) 
    return merge_ocr_result(res_lines)

# 读取磁盘文件进行OCR识别
def ocr_image_from_path(path):
    res_lines = cn_ocr.ocr(path) 
    return merge_ocr_result(res_lines)

# 合并多行OCR结果
def merge_ocr_result(res_lines):
    res = [''.join(line_p) for line_p in res_lines]
    temp_res = '\n'.join(res)
    return temp_res

def is_chs_char(ch):
    if '\u4e00' <= ch <= '\u9fff':
        return True
    return False