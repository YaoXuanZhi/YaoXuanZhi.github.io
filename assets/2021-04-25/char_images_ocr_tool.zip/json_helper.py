# !/user/bin/env python
# -*- coding:utf-8 -*- 
import os, json, codecs

def get_default_config():
    return {"ocr_engine": "cnocr", "ocr_result": {}}

def load_config_from_path(json_path):
    json_obj = get_default_config()
    if os.path.exists(json_path):
        with codecs.open(json_path, mode="r", encoding="utf-8", errors='ignore') as f:
            json_str = f.read()
            json_obj = json.loads(json_str)
            f.close()
    return json_obj

def load_config(output_dir):
    json_path = "%s/ocr_result.json" % (output_dir)
    return load_config_from_path(json_path)

def save_config(config_obj, output_dir):
    json_name = "%s/ocr_result.json" % (output_dir)
    with open(json_name, 'w', encoding="utf-8") as f:
        json.dump(config_obj, f, ensure_ascii=False, indent=4)

def load_error_config(output_dir):
    json_name = "%s/ocr_error.json" % (output_dir)
    json_obj = {}
    if os.path.exists(json_name):
        with codecs.open(json_name, mode="r", encoding="utf-8", errors='ignore') as f:
            json_str = f.read()
            json_obj = json.loads(json_str)
            f.close()
    return json_obj

def save_error_config(config_obj, output_dir):
    if len(config_obj) > 0:
        json_name = "%s/ocr_error.json" % (output_dir)
        with open(json_name, 'w', encoding="utf-8") as f:
            json.dump(config_obj, f, ensure_ascii=False, indent=4)

def is_chs_char(ch):
    if '\u4e00' <= ch <= '\u9fff':
        return True
    return False