alias check_package_info='Check_package_info(){ cd $toolkit_root; pacman -Ss $1;};Check_package_info'
alias show_help='pacman --help'