import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from flask import Flask, render_template, request, jsonify, Request
from vendor import *
import argparse

# 创建 Flask 应用实例
app = Flask(__name__)
redisService = RedisService("rank")

def jsonifyEx(jsonObj, request:Request):
    ipEndPoint = request.remote_addr + ":" + str(request.environ.get('SERVER_PORT'))
    jsonObj["ip_end_point"] = ipEndPoint
    return jsonify(jsonObj)

@app.route('/')
def home():
    return render_template('index.html', message="Hello, Flask!")

@app.route('/api/update_player_score', methods=['POST'])
def update_player_score():
    data = request.get_json()   # 获取JSON数据
    jsonObj = json.loads(data)
    rankType = jsonObj['rank_type']
    playerId = jsonObj['player_id']
    score = jsonObj['score']
    playerInfo = jsonObj['player_info']
    redisService.updateRankScore(rankType, playerId, int(score), playerInfo)
    # 获得当前服务器的ip地址和端口号
    return jsonifyEx(data, request)

@app.route('/api/delete_player_score', methods=['POST'])
def delete_player_score():
    data = request.get_json()   # 获取JSON数据
    jsonObj = json.loads(data)
    rankType = jsonObj['rank_type']
    playerId = jsonObj['player_id']
    redisService.deleteRankScore(rankType, int(playerId))
    return jsonifyEx(data, request)

@app.route('/api/clear_by_rank_type', methods=['POST'])
def clear_by_rank_type():
    rankType = request.args.get('rank_type')
    redisService.clearByRankType(rankType)
    return f"已经清空排行榜了 {time.time()}"

@app.route('/api/print_by_rank_type', methods=['POST', 'GET'])
def print_by_rank_type():
    rankType = request.args.get('rank_type')
    result = redisService.getRankList(rankType, 0, 100)
    data = {
        "rank_infos" : result,
    }
    return jsonifyEx(data, request)

@app.route('/api/get_player_rank_info', methods=['POST'])
def get_player_rank_info():
    rankType = request.args.get('rank_type')
    playerId = request.args.get('player_id')
    data = redisService.getPlayerRankInfo(rankType, playerId)
    return jsonifyEx(data, request)

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--redis_host", type=str, default='localhost')
    parser.add_argument("--redis_port", type=int, default=6379)
    return parser.parse_args()

# 运行应用
if __name__ == '__main__':
    args = parse_args()
    port = args.port
    redisService.initRedis(args.redis_host, args.redis_port)

    app.run(debug=True, port=port)