from flask import Flask, render_template, request, jsonify
from vendor import *

# 创建 Flask 应用实例
app = Flask(__name__)

# 定义路由和视图函数
# @app.route('/')
# def home():
#     return "Hello, Flask!"

@app.route('/')
def home():
    return render_template('index.html', message="Hello, Flask!")

# 监听/api/player_shot?player_id=111&top_n=10的url，并打印出来
# @app.route('/api/player_shot')
# def player_shot():
#     player_id = request.args.get('player_id')
#     top_n = request.args.get('top_n')
#     print(f"player_id: {player_id}, top_n: {top_n}")
#     return "player_shot"

#示例 http://127.0.0.1:5000/api/rank/1/get_top_n?top_n=100
@app.route('/api/rank/<int:rank_type>/get_top_n')
def get_top_n(rank_type):
    top_n = request.args.get('top_n')
    return f"查询排行榜信息：排行榜类型：{rank_type} 前N名{top_n}"

@app.route('/api/rank/<int:rank_type>/get_top_2')
def get_top_n2(rank_type):
    data = {
        "key" : "value",
        "rank_type" : rank_type,
    }
    return jsonify(data)

# 运行应用
if __name__ == '__main__':
    app.run(debug=True)