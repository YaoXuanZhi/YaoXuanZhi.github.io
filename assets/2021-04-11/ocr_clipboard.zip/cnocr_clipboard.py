# -*- coding: utf-8 -*-
import win32.win32clipboard as win32clipboard
from PIL import Image, ImageDraw, ImageGrab
import os

# 读取PIL image进行OCR识别
def ocr_image_from_pil(image):
    from cnocr import CnOcr 
    import numpy as np
    cn_ocr = CnOcr() 
    nd_array = np.asarray(image.convert('RGB'))
    res_lines = cn_ocr.ocr(nd_array) 
    res = [''.join(line_p) for line_p in res_lines]
    temp_res = '\n'.join(res)
    return temp_res

# 读取剪贴板上的图像数据进行OCR识别
def try_ocr_clipboard():
    ocr_result = ""
    im = ImageGrab.grabclipboard()
    if not im == None:
        return ocr_image_from_pil(im)
    return ocr_result

def set_text_to_clipboard(text):
    text_bytes = bytes(text, encoding="utf8")
    win32clipboard.OpenClipboard()
    win32clipboard.SetClipboardText(text)
    win32clipboard.CloseClipboard()

def ocr_clipboard():
    ocr_result = try_ocr_clipboard()
    if (len(ocr_result) > 0):
        set_text_to_clipboard(ocr_result)
        print("剪贴板OCR结果：\n%s" % (ocr_result))
        os.system("pause")

ocr_clipboard()