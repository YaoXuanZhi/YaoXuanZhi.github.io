```shell
cd php_dir
pip3 install -r requirements.txt
python main.py
```
