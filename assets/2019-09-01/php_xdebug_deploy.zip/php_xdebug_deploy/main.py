# !/user/bin/env python
# -*- coding:utf-8 -*- 

import os, sys, subprocess, locale, shutil
import requests, codecs, urllib, configparser
from bs4 import BeautifulSoup
from sys import stdout

# 根据phpinfo查询在xdebug.org上提取xdebug.dll的下载连接
def get_xdebug_download_page(phpinfo):
    url = 'https://xdebug.org/wizard.php'
    data = {
        "data": phpinfo,
        "submit": "Analyse my phpinfo() output"
    }
    headers = {
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36",
        "Origin": "https://xdebug.org",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Referer": "https://xdebug.org/wizard.php",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.9",
    }
    return requests.post(url=url, headers=headers, data=data).text

# 提取页面上的xdebug的下载链接
def find_xdebug_download_link(html):
    soup = BeautifulSoup(html, features="html.parser")
    return soup.find("ol").find("a")["href"]

# 获取phpinfo
def get_php_info():
    phpinfo = read_commandline("php -i phpinfo();")
    substr_flag = phpinfo.find("___________________")
    return phpinfo[0:substr_flag]

# 获取shell的输出结果
def read_commandline(command_str):
    output_str = ""
    ps = subprocess.Popen(command_str, stdin=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)
    while True:
        data = ps.stdout.readline()
        if data == b'':
            if ps.poll() is not None:
                break
        else:
            output_str = output_str + data.decode(codecs.lookup(locale.getpreferredencoding()).name)
    return output_str

# 下载文件
def download_file(url, file_path):
    r = requests.get(url)
    with codecs.open(file_path,'wb') as f:
        f.write(r.content)

# Refer to : [Python3 requests文件下载 期间显示文件信息和下载进度代码实例](https://www.jb51.net/article/167786.htm)
def download_file_with_process(url, file_path):
    with codecs.open(file_path, "wb") as fw:
        with requests.get(url, stream=True) as r:
            filesize = r.headers["Content-Length"]
            chunk_size = 128
            times = int(filesize) // chunk_size
            show = 1 / times
            show2 = 1 / times
            start = 1
            for chunk in r.iter_content(chunk_size):
              fw.write(chunk)
              if start <= times:
                stdout.write(f"download process : {show:.2%}\r")
                start += 1
                show += show2

def check_php_cfg(php_cfg):
    default_php_cfg = php_cfg+"-development"
    if not os.path.exists(php_cfg):
        shutil.copy(default_php_cfg, php_cfg)

# 更新php.ini上的xdebug配置
def update_php_cfg(php_cfg, xdebug_path):
    conf = configparser.ConfigParser()
    conf.read(php_cfg)

    xdebug_section_name = "xdebug"
    if conf.has_section(xdebug_section_name):
        pass
    else:
        conf.add_section(xdebug_section_name)
    conf.set(xdebug_section_name, "zend_extension", xdebug_path)
    conf.set(xdebug_section_name, "xdebug.remote_enable", "1")
    conf.set(xdebug_section_name, "xdebug.remote_autostart", "1")
    # conf.set(xdebug_section_name, "xdebug.remote_host", "10.0.2.2")
    # conf.set(xdebug_section_name, "xdebug.remote_port", "9000")

    outfile = codecs.open(php_cfg, "w")
    conf.write(outfile)
    outfile.close()

if __name__ == '__main__':
    php_cfg = "php.ini"

    print("-------------check php.ini---------------")
    check_php_cfg(php_cfg)

    print("-------------fetch phpinfo---------------")
    phpinfo = get_php_info()

    print("-----fetch xdebug.dll download link------")
    html = get_xdebug_download_page(phpinfo)
    download_link = find_xdebug_download_link(html)

    print("----------download xdebug.dll------------")
    dir_path = "./ext"
    file_name = os.path.basename(download_link) 
    file_path = os.path.join(dir_path, file_name)
    full_file_path = os.path.abspath(file_path)
    if not os.path.exists(file_path):
        # download_file(download_link, full_file_path)
        download_file_with_process(download_link, full_file_path)
    else:
        print("%(full_file_path)s already exists, skip download ……" % {'full_file_path' : full_file_path})

    update_php_cfg(php_cfg, full_file_path)