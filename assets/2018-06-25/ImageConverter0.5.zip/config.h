// the configured options and settings for Tutorial
#define APP_VERSION_MAJOR 1
#define APP_VERSION_MINOR 0
