#ifndef __GDIPLUSWRAPPER_H
#define __GDIPLUSWRAPPER_H

/*
Refrence:
 - [Using Image Encoders and Decoders](https://docs.microsoft.com/zh-cn/windows/desktop/gdiplus/-gdiplus-using-image-encoders-and-decoders-use)
 - [GDI+ Bitmap��GDI HBITMAP��ת](https://blog.csdn.net/wenzhou1219/article/details/78303690)
*/

#include <windows.h>
#include <gdiplus.h>

class CGdiplusWrapper {
public:
	~CGdiplusWrapper();
	static CGdiplusWrapper & GetInstance();
	Gdiplus::Image* LoadImage(wchar_t *szImgPath);
	bool SaveImage(wchar_t *szImgPath, Gdiplus::Image *pImg = NULL, wchar_t* szImgType = NULL);

protected:
	CGdiplusWrapper();
	void InitGdiplus();
	void ReleaseGdiplus();
	int GetEncoderClsid(const wchar_t* format, CLSID* pClsid);

private:
	ULONG_PTR gdiplustoken;
};

#endif