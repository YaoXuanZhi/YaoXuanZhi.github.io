#include "ImgSaver.h"

bool CImgSaverByGdiplus::SaveImage(wchar_t * szImgPath, Gdiplus::Image* pImg, wchar_t* szImgType)
{
	return CGdiplusWrapper::GetInstance().SaveImage(szImgPath, pImg, szImgType);
}

void CImgSaverByGdiplus::Print()
{
	printf("֧�ֱ���Ϊ[bmp|png|jpg|jpeg|gif|tiff]��ʽ\n");
}
