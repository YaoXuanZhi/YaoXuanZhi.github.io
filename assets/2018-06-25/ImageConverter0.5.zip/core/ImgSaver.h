#ifndef __IMGSAVER_H
#define __IMGSAVER_H
#include "ImgFactory.h"
#include "GdiplusWrapper.h"
class CImgSaverByGdiplus :public CImgSaver
{
public:
	bool SaveImage(wchar_t * szImgPath, Gdiplus::Image* pImg, wchar_t* szImgType = NULL);
	void Print();
};

#endif