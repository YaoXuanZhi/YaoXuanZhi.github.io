#include "ImgLoader.h"

Gdiplus::Image* CImgLoaderByGdiplus::LoadImage(wchar_t * szImgPath)
{
	return CGdiplusWrapper::GetInstance().LoadImage(szImgPath);
}

void CImgLoaderByGdiplus::Print()
{
	printf("֧�ּ���[bmp|png|jpg|jpeg|gif|tiff]��ʽ\n");
}
