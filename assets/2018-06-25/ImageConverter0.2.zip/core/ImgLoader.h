#ifndef __IMGLOADER_H
#define __IMGLOADER_H
#include "ImgFactory.h"
#include "GdiplusWrapper.h"
class CImgLoaderByGdiplus :public CImgLoader {
public:
	Gdiplus::Image* LoadImage(wchar_t * szImgPath);
	void Print();
};
#endif