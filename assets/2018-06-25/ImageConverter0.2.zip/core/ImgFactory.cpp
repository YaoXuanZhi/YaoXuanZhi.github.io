#include "ImgFactory.h"
#pragma warning(disable:4996)
CImgLoader::CImgLoader()
{

}

CImgLoader::~CImgLoader()
{

}

const wchar_t* CImgLoader::GetImgType()
{
	return NULL;
}

void CImgLoader::Print()
{
	printf("δʵ��ͼƬ������\n");
}

Gdiplus::Image* CImgLoader::LoadImage(wchar_t * szImgPath)
{
	return NULL;
}

CImgSaver::CImgSaver()
{

}

CImgSaver::~CImgSaver()
{

}

const wchar_t* CImgSaver::GetImgType()
{
	return NULL;
}

void CImgSaver::Print()
{
	printf("δʵ��ͼƬ������\n");
}

bool CImgSaver::SaveImage(wchar_t * szImgPath, Gdiplus::Image* pImg, wchar_t* szImgType)
{
	return NULL;
}

void CImageFactory::RegisterLoader(IForwarder<CImgLoader>* pObj, wchar_t* szImgType)
{
	if (!pObj) return;
	const wchar_t *szType = szImgType? szImgType : pObj->InvokeClass()->GetImgType();
	if (szType)
		m_loaderFactory.RegisterFactory(szType, pObj);
}

void CImageFactory::RegisterSaver(IForwarder<CImgSaver>* pObj, wchar_t* szImgType)
{
	if (!pObj) return;
	const wchar_t *szType = szImgType? szImgType : pObj->InvokeClass()->GetImgType();
	if (szType)
		m_saverFactory.RegisterFactory(szType, pObj);
}

Gdiplus::Image* CImageFactory::InvokeLoader(wchar_t * szImgPath)
{
	if (!szImgPath) return false;
	wchar_t szImgExt[10] = {0};
	_wsplitpath(szImgPath, NULL, NULL, NULL, szImgExt);
	CImgLoader* pLoader = m_loaderFactory.InvokeClass(&szImgExt[1]);
	if (pLoader)
		return pLoader->LoadImage(szImgPath);
	else {
		std::list<std::wstring> imgTypes = m_loaderFactory.GetKeys();
		std::list<std::wstring>::iterator it = imgTypes.begin();
        wprintf(L"�ݲ�֧��%sͼƬ��ʽ������֧�ֵĸ�ʽ�У�", &szImgExt[1]);
		for (; it!=imgTypes.end();it++)
		{
			wprintf(L"%s%s", it != imgTypes.begin() ? L"|" : L"", it->c_str());
		}
		wprintf(L"\b\n");
	}
	return NULL;
}

bool CImageFactory::InvokeSaver(wchar_t * szImgPath, Gdiplus::Image* pImg, wchar_t* szImgType)
{
	if (!pImg || !szImgPath) return false;
	wchar_t szImgExt[10] = {0};
	_wsplitpath(szImgPath, NULL, NULL, NULL, szImgExt);
	CImgSaver* pLoader = m_saverFactory.InvokeClass(szImgType? szImgType : &szImgExt[1]);
	if (pLoader)
		return pLoader->SaveImage(szImgPath, pImg, szImgType);
	else {
		std::list<std::wstring> imgTypes = m_loaderFactory.GetKeys();
		std::list<std::wstring>::iterator it = imgTypes.begin();
		wprintf(L"�ݲ�֧��%sͼƬ��ʽ������֧�ֵĸ�ʽ�У�", &szImgExt[1]);
		for (; it != imgTypes.end(); it++)
		{
			wprintf(L"%s%s", it != imgTypes.begin() ? L"|" : L"", it->c_str());
		}
		wprintf(L"\b\n");
	}
	return false;
}
