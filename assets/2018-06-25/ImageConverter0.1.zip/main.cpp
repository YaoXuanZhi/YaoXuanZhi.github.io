#include <stdio.h>

int main()
{
    printf("Hi,ImageConverter!\n");
    getchar();
    return 1;
}